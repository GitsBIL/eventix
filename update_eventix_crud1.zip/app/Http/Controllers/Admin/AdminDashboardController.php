<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Event;
use App\Models\OrderItem;
use App\Models\User;
use Inertia\Inertia;

class AdminDashboardController extends Controller
{
    public function index()
    {
        // 1. Ambil Statistik Utama
        $totalRevenue = Order::sum('TotalAmount');
        $ticketsSold = OrderItem::sum('Qty');
        $activeEvents = Event::where('Status', 1)->count();
        $totalCustomers = User::where('Role', 'customer')->count();

        // 2. Data Penjualan per Kategori (Dinamis dari Database)
        // Kita hitung total Qty tiap CategoryName melalui relasi order_items -> ticket_categories
        $categorySalesRaw = OrderItem::join('ticket_categories', 'order_items.TicketCategoryID', '=', 'ticket_categories.ID')
            ->selectRaw('ticket_categories.CategoryName, SUM(order_items.Qty) as total')
            ->groupBy('ticket_categories.CategoryName')
            ->get();

        // Siapkan warna buat chart donut agar tetap estetik
        $chartColors = ['#3b82f6', '#10b981', '#8b5cf6', '#ef4444', '#f59e0b'];
        $categorySales = $categorySalesRaw->map(function ($item, $index) use ($chartColors) {
            return [
                'label' => $item->CategoryName,
                'value' => (int)$item->total,
                'color' => $chartColors[$index % count($chartColors)]
            ];
        });

        // 3. Data Transaksi Terbaru (Join Komplit)
        $recentTransactions = Order::join('users', 'orders.CustomerID', '=', 'users.ID')
            ->join('order_items', 'orders.ID', '=', 'order_items.OrderID')
            ->join('ticket_categories', 'order_items.TicketCategoryID', '=', 'ticket_categories.ID')
            ->join('events', 'ticket_categories.EventID', '=', 'events.ID')
            ->select(
                'orders.ID',
                'users.FullName',
                'events.EventName',
                'ticket_categories.CategoryName',
                'orders.TotalAmount',
                'orders.PaymentStatus'
            )
            ->orderBy('orders.ID', 'desc')
            ->limit(5)
            ->get()
            ->map(function ($trx) {
                // Generate inisial otomatis (Contoh: Nabil Putra -> NP)
                $names = explode(' ', $trx->FullName);
                $initial = count($names) > 1 
                    ? strtoupper(substr($names[0], 0, 1) . substr($names[1], 0, 1))
                    : strtoupper(substr($names[0], 0, 2));

                return [
                    'id' => $trx->ID,
                    'initial' => $initial,
                    'name' => $trx->FullName,
                    'event' => $trx->EventName,
                    'category' => $trx->CategoryName,
                    'amount' => 'Rp ' . number_format($trx->TotalAmount, 0, ',', '.'),
                    'status' => $trx->PaymentStatus
                ];
            });

        return Inertia::render('Admin/Dashboard', [
            'stats' => [
                'totalRevenue' => 'Rp ' . number_format($totalRevenue, 0, ',', '.'),
                'ticketsSold' => number_format($ticketsSold, 0, ',', '.'),
                'activeEvents' => $activeEvents,
                'totalCustomers' => $totalCustomers,
            ],
            'categorySales' => $categorySales,
            'recentTransactions' => $recentTransactions
        ]);
    }
}