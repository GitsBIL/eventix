<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Event;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage; // Wajib import ini buat hapus file

class EventController extends Controller
{
    public function index()
    {
        $events = Event::orderBy('ID', 'desc')->get()->map(function ($event) {
            // Generate inisial buat profil pencipta event (RD, BH, dkk)
            $names = explode(' ', trim($event->CreatedBy ?? 'System Admin'));
            $initial = count($names) >= 2
                ? strtoupper(substr($names[0], 0, 1) . substr($names[1], 0, 1))
                : strtoupper(substr($names[0], 0, 2));

            return [
                'ID' => $event->ID,
                'EventName' => $event->EventName,
                'Description' => $event->Description,
                'Location' => $event->Location,
                'EventDate' => $event->EventDate,
                'BannerImage' => $event->BannerImage, // Simpan path asli
                'Status' => $event->Status,
                'creator_initial' => $initial, // Kirim inisial ke frontend
            ];
        });
        
        return Inertia::render('Admin/Events/Index', [
            'events' => $events
        ]);
    }

    public function store(Request $request)
    {
        // Validasi input, BannerImage ganti jadi tipe 'image'
        $request->validate([
            'EventName' => 'required|string|max:150',
            'EventDate' => 'nullable|date',
            'Location' => 'nullable|string',
            'Description' => 'nullable|string',
            'BannerImage' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048', // Maksimal 2MB
            'Status' => 'nullable|integer|in:0,1',
        ]);

        // Proses Upload File Gambar
        $path = null;
        if ($request->hasFile('BannerImage')) {
            // Simpan di: storage/app/public/banners
            $path = $request->file('BannerImage')->store('banners', 'public');
        }

        Event::create([
            'OrganizerID' => Auth::user()->ID ?? 1,
            'EventName' => $request->EventName,
            'Description' => $request->Description,
            'Location' => $request->Location,
            'EventDate' => $request->EventDate,
            'BannerImage' => $path, // Simpan path, misal: 'banners/namagambar.jpg'
            'CompanyCode' => 'EVTX',
            'Status' => $request->Status ?? 1,
            'IsDeleted' => 0,
            'CreatedBy' => Auth::user()->FullName ?? 'System',
            'CreatedDate' => now(),
        ]);

        return redirect()->back();
    }

    public function update(Request $request, $id)
    {
        // Inertia ngirim data file upload via update pake POST spoofing _method=PUT
        $request->validate([
            'EventName' => 'required|string|max:150',
            'EventDate' => 'nullable|date',
            'Location' => 'nullable|string',
            'Description' => 'nullable|string',
            'BannerImage' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048', // Boleh kosong kalo gak diganti
            'Status' => 'nullable|integer|in:0,1',
        ]);

        $event = Event::findOrFail($id);
        
        $path = $event->BannerImage; // Default pake gambar lama

        // Kalau ada file baru diupload
        if ($request->hasFile('BannerImage')) {
            // Hapus gambar lama dari storage biar gak numpuk sampah
            if ($event->BannerImage) {
                Storage::disk('public')->delete($event->BannerImage);
            }
            // Upload gambar baru
            $path = $request->file('BannerImage')->store('banners', 'public');
        }

        $event->update([
            'EventName' => $request->EventName,
            'Description' => $request->Description,
            'Location' => $request->Location,
            'EventDate' => $request->EventDate,
            'BannerImage' => $path,
            'Status' => $request->Status,
            'LastUpdatedBy' => Auth::user()->FullName ?? 'System',
            'LastUpdatedDate' => now(),
        ]);

        return redirect()->back();
    }

    public function destroy($id)
    {
        $event = Event::findOrFail($id);

        // Hapus file banner dari storage sebelum hapus datanya
        if ($event->BannerImage) {
            Storage::disk('public')->delete($event->BannerImage);
        }

        $event->delete();
        return redirect()->back();
    }
}