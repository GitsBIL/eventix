import React, { useState } from 'react';
import { Head, Link, usePage, useForm, router } from '@inertiajs/react';
import Swal from 'sweetalert2';

export default function EventIndex({ events = [] }) {
    const { auth } = usePage().props;
    const [showModal, setShowModal] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const [editId, setEditId] = useState(null);

    const { data, setData, post, put, processing, reset, errors, clearErrors } = useForm({
        EventName: '',
        EventDate: '',
        Location: '',
        Description: '',
        Status: 1,
    });

    const submit = (e) => {
        e.preventDefault();
        if (isEditing) {
            put(route('admin.events.update', editId), { onSuccess: () => setShowModal(false) });
        } else {
            post(route('admin.events.store'), { onSuccess: () => { setShowModal(false); reset(); } });
        }
    };

    return (
        <div className="flex h-screen bg-[#0C0F16] text-gray-300 font-sans overflow-hidden">
            <Head title="Events Management - Eventix" />

            {/* SIDEBAR */}
            <aside className="w-64 bg-[#12161f] border-r border-white/5 flex flex-col justify-between h-full hidden md:flex shrink-0">
                <div>
                    <div className="h-20 flex items-center px-8 border-b border-white/5">
                        <span className="text-xl font-black text-white uppercase tracking-tighter">EVEN<span className="text-[#e8ff47]">TIX</span></span>
                    </div>
                    <nav className="px-4 py-6">
                        <p className="px-4 text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-4">Management</p>
                        <ul className="space-y-2">
                            <li><Link href={route('admin.dashboard')} className="flex items-center gap-3 px-4 py-2.5 text-gray-400 hover:text-white"><div className="w-1.5 h-1.5 rounded-full bg-gray-600"></div><span className="text-sm font-medium">Dashboard</span></Link></li>
                            <li><Link href={route('admin.events.index')} className="flex items-center gap-3 px-4 py-2.5 bg-white/5 text-white rounded-xl border border-white/10 shadow-sm"><div className="w-1.5 h-1.5 rounded-full bg-blue-400"></div><span className="text-sm font-medium">Events</span></Link></li>
                        </ul>
                    </nav>
                </div>

                {/* PROFILE & LOGOUT SECTION */}
                <div className="p-4 border-t border-white/5">
                    <Link 
                        href={route('logout')} 
                        method="post" 
                        as="button"
                        className="w-full flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/5 hover:bg-red-500/10 hover:border-red-500/30 transition-all group"
                    >
                        <div className="flex items-center gap-3 overflow-hidden">
                            <div className="w-10 h-10 rounded-full bg-[#e8ff47]/10 flex items-center justify-center text-[#e8ff47] font-bold border border-[#e8ff47]/20 text-xs shrink-0 group-hover:bg-red-500/20 group-hover:text-red-400 transition-colors">
                                {auth.user.FullName.charAt(0)}
                            </div>
                            <div className="text-left truncate">
                                <p className="text-sm font-bold text-white truncate group-hover:text-red-400 transition-colors">{auth.user.FullName}</p>
                                <p className="text-[10px] text-gray-500 uppercase tracking-tighter group-hover:text-red-500 transition-colors">System {auth.user.Role}</p>
                            </div>
                        </div>
                        <svg className="w-4 h-4 text-gray-500 group-hover:text-red-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                    </Link>
                </div>
            </aside>

            {/* MAIN CONTENT */}
            <main className="flex-1 flex flex-col h-full overflow-hidden bg-[#0C0F16]">
                <header className="h-20 flex items-center justify-between px-8 border-b border-white/5 bg-[#12161f]/50 backdrop-blur-sm shrink-0">
                    <h1 className="text-xl font-bold text-white uppercase tracking-widest">Events Management</h1>
                    <button onClick={() => { setIsEditing(false); reset(); setShowModal(true); }} className="px-5 py-2 bg-[#e8ff47] text-black rounded-lg text-xs font-black uppercase tracking-widest shadow-[0_0_20px_rgba(232,255,71,0.2)] hover:scale-105 transition-all">+ New Event</button>
                </header>

                <div className="flex-1 overflow-y-auto p-8">
                    <div className="bg-[#12161f] rounded-2xl border border-white/5 shadow-2xl overflow-hidden">
                        <table className="w-full text-left">
                            <thead>
                                <tr className="text-[10px] font-bold text-gray-500 uppercase border-b border-white/5">
                                    <th className="px-6 py-4">Event Name</th>
                                    <th className="px-6 py-4">Location & Date</th>
                                    <th className="px-6 py-4 text-center">Status</th>
                                    <th className="px-6 py-4 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-white/5">
                                {events.map((event) => (
                                    <tr key={event.ID} className="hover:bg-white/[0.01]">
                                        <td className="px-6 py-4 text-sm font-bold text-white">{event.EventName}</td>
                                        <td className="px-6 py-4">
                                            <p className="text-sm text-gray-300 font-medium">{event.Location}</p>
                                            <p className="text-[10px] text-gray-500">{event.EventDate}</p>
                                        </td>
                                        <td className="px-6 py-4 text-center">
                                            <span className="px-2 py-1 bg-green-500/10 text-green-400 text-[9px] font-black rounded border border-green-500/20 uppercase">Active</span>
                                        </td>
                                        <td className="px-6 py-4 text-right">
                                            <div className="flex gap-2 justify-end">
                                                <button onClick={() => { setIsEditing(true); setEditId(event.ID); setData(event); setShowModal(true); }} className="p-2 bg-blue-500/10 text-blue-400 rounded-lg hover:bg-blue-500 hover:text-white transition-all"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg></button>
                                                <button onClick={() => router.delete(route('admin.events.destroy', event.ID))} className="p-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500 hover:text-white transition-all"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* MODAL (Bisa ditambah kalau perlu, ini placeholder) */}
                {showModal && <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">... Form Content ...</div>}
            </main>
        </div>
    );
}