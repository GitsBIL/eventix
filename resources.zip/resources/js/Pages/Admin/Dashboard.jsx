import React from 'react';
import { Head, Link, usePage } from '@inertiajs/react';

export default function AdminDashboard({ stats, categorySales, recentTransactions }) {
    const { auth } = usePage().props;
    const totalQty = categorySales.reduce((acc, curr) => acc + curr.value, 0);

    return (
        <div className="flex h-screen bg-[#0C0F16] text-gray-300 font-sans overflow-hidden">
            <Head title="Admin Dashboard - Eventix" />

            {/* SIDEBAR */}
            <aside className="w-64 bg-[#12161f] border-r border-white/5 flex flex-col justify-between h-full hidden md:flex shrink-0">
                <div>
                    <div className="h-20 flex items-center px-8 border-b border-white/5">
                        <span className="text-xl font-black text-white uppercase tracking-tighter">EVEN<span className="text-[#e8ff47]">TIX</span></span>
                    </div>
                    <nav className="px-4 py-6">
                        <p className="px-4 text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-4">Management</p>
                        <ul className="space-y-2">
                            <li>
                                <Link href={route('admin.dashboard')} className="flex items-center gap-3 px-4 py-2.5 bg-white/5 text-white rounded-xl border border-white/10 shadow-sm">
                                    <div className="w-1.5 h-1.5 rounded-full bg-[#e8ff47]"></div>
                                    <span className="text-sm font-medium">Dashboard</span>
                                </Link>
                            </li>
                            <li><Link href={route('admin.events.index')} className="flex items-center gap-3 px-4 py-2.5 text-gray-400 hover:text-white"><div className="w-1.5 h-1.5 rounded-full bg-gray-600"></div><span className="text-sm font-medium">Events</span></Link></li>
                            <li><Link href="#" className="flex items-center gap-3 px-4 py-2.5 text-gray-400 hover:text-white"><div className="w-1.5 h-1.5 rounded-full bg-gray-600"></div><span className="text-sm font-medium">Tickets</span></Link></li>
                            <li><Link href="#" className="flex items-center gap-3 px-4 py-2.5 text-gray-400 hover:text-white"><div className="w-1.5 h-1.5 rounded-full bg-gray-600"></div><span className="text-sm font-medium">Transactions</span></Link></li>
                        </ul>
                    </nav>
                </div>

                {/* PROFILE & LOGOUT SECTION */}
                <div className="p-4 border-t border-white/5">
                    <Link 
                        href={route('logout')} 
                        method="post" 
                        as="button"
                        className="w-full flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/5 hover:bg-red-500/10 hover:border-red-500/30 transition-all group"
                    >
                        <div className="flex items-center gap-3 overflow-hidden">
                            <div className="w-10 h-10 rounded-full bg-[#e8ff47]/10 flex items-center justify-center text-[#e8ff47] font-bold border border-[#e8ff47]/20 text-xs shrink-0 group-hover:bg-red-500/20 group-hover:text-red-400 transition-colors">
                                {auth.user.FullName.charAt(0)}
                            </div>
                            <div className="text-left truncate">
                                <p className="text-sm font-bold text-white truncate group-hover:text-red-400 transition-colors">{auth.user.FullName}</p>
                                <p className="text-[10px] text-gray-500 uppercase tracking-tighter group-hover:text-red-500 transition-colors">System {auth.user.Role}</p>
                            </div>
                        </div>
                        <svg className="w-4 h-4 text-gray-500 group-hover:text-red-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                    </Link>
                </div>
            </aside>

            {/* MAIN CONTENT */}
            <main className="flex-1 flex flex-col h-full overflow-hidden bg-[#0C0F16]">
                <header className="h-20 flex items-center justify-between px-8 border-b border-white/5 bg-[#12161f]/50 backdrop-blur-sm shrink-0">
                    <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-[#e8ff47] animate-pulse"></div>
                        <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">System Operational</span>
                    </div>
                </header>

                <div className="flex-1 overflow-y-auto p-8 space-y-8">
                    {/* STAT CARDS */}
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
                        <div className="bg-[#12161f] p-6 rounded-2xl border border-white/5 shadow-xl">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Total Revenue</p>
                            <p className="text-3xl font-black text-white">{stats.totalRevenue}</p>
                        </div>
                        <div className="bg-[#12161f] p-6 rounded-2xl border border-white/5 shadow-xl">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Tickets Sold</p>
                            <p className="text-3xl font-black text-white">{stats.ticketsSold}</p>
                        </div>
                        <div className="bg-[#12161f] p-6 rounded-2xl border border-white/5 shadow-xl">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Active Events</p>
                            <p className="text-3xl font-black text-white">{stats.activeEvents}</p>
                        </div>
                        <div className="bg-[#12161f] p-6 rounded-2xl border border-white/5 shadow-xl">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Total Customers</p>
                            <p className="text-3xl font-black text-white">{stats.totalCustomers}</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
                        {/* TRANSACTIONS TABLE */}
                        <div className="xl:col-span-2 bg-[#12161f] rounded-2xl border border-white/5 shadow-2xl overflow-hidden">
                            <div className="p-6 border-b border-white/5"><h3 className="text-xs font-black text-white uppercase tracking-widest">Live Transactions</h3></div>
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="text-[10px] font-bold text-gray-500 uppercase border-b border-white/5">
                                        <th className="px-6 py-4">Customer</th>
                                        <th className="px-6 py-4">Event Info</th>
                                        <th className="px-6 py-4">Amount</th>
                                        <th className="px-6 py-4">Status</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5">
                                    {recentTransactions.map((trx) => (
                                        <tr key={trx.id} className="hover:bg-white/[0.01]">
                                            <td className="px-6 py-4 flex items-center gap-3">
                                                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400 text-[10px] font-bold">{trx.initial}</div>
                                                <span className="text-sm font-bold text-white">{trx.name}</span>
                                            </td>
                                            <td className="px-6 py-4 text-xs text-gray-300 font-medium">{trx.event}</td>
                                            <td className="px-6 py-4 text-sm font-black text-white">{trx.amount}</td>
                                            <td className="px-6 py-4"><span className="px-2 py-1 bg-green-500/10 text-green-400 text-[9px] font-black rounded border border-green-500/20 uppercase">{trx.status}</span></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        {/* SALES BY CATEGORY */}
                        <div className="bg-[#12161f] p-6 rounded-2xl border border-white/5 shadow-2xl">
                            <h3 className="text-xs font-black text-white uppercase tracking-widest mb-6">Sales by Category</h3>
                            <div className="space-y-6">
                                {categorySales.map((item, i) => (
                                    <div key={i}>
                                        <div className="flex justify-between items-end mb-2">
                                            <span className="text-[10px] font-bold text-gray-400 uppercase">{item.label}</span>
                                            <span className="text-xs font-black text-white">{item.value} Sold</span>
                                        </div>
                                        <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                                            <div className="h-full rounded-full" style={{ width: `${(item.value / (totalQty || 1)) * 100}%`, backgroundColor: item.color }}></div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
}