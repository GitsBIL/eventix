<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\GoogleController;
use App\Http\Controllers\TwoFactorController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\Admin\AdminDashboardController;
use App\Http\Controllers\Admin\EventController;
use App\Http\Controllers\Admin\TicketController;
use App\Http\Controllers\Admin\TransactionController;
use App\Http\Controllers\Admin\CustomerController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

// Route Halaman Utama (Public) - Menampilkan Data Event Asli
Route::get('/', function () {
    // Tarik data event yang statusnya aktif (1) dari database
    $events = \App\Models\Event::where('Status', 1)->orderBy('ID', 'desc')->get()->map(function($event) {
        return [
            'id' => $event->ID,
            'title' => $event->EventName,
            // Format tanggal jadi cakep (Contoh: 02 Dec 2026)
            'date' => $event->EventDate ? date('d M Y', strtotime($event->EventDate)) : 'TBA',
            'venue' => $event->Location,
            // Panggil gambar dari storage, kalau kosong kasih gambar default
            'image' => $event->BannerImage ? '/storage/' . $event->BannerImage : 'https://images.unsplash.com/photo-1533174000220-1110a30b42f1?w=800&q=80',
            // Harga diset 'Cek Tiket' dulu sampai nanti kita bikin sistem Tiket-nya
            'price' => 'Cek Tiket', 
            'tag' => 'Live Event'
        ];
    });

    return Inertia::render('WelcomePublic', [
        'publicEvents' => $events // Lempar data aslinya ke React
    ]); 
})->name('home');

// OAuth Google
Route::get('auth/google', [GoogleController::class, 'redirect'])->name('google.redirect');
Route::get('auth/google/callback', [GoogleController::class, 'callback'])->name('google.callback');

// Area User Terautentikasi (Customer)
Route::middleware(['auth', 'verified'])->group(function () {
    
    // Redirect user ke dashboard masing-masing berdasarkan role
    Route::get('/dashboard', function () {
        $user = Auth::user();
        if ($user->Role === 'Admin' || $user->Role === 'Super Admin') {
            return redirect()->route('admin.dashboard'); 
        }
        return redirect()->route('home'); 
    })->name('dashboard');

    // Halaman list tiket customer
    Route::get('/customer/dashboard', function () {
        $myTickets = \App\Models\Order::where('CustomerID', Auth::user()->ID)
            ->join('order_items', 'orders.ID', '=', 'order_items.OrderID')
            ->join('ticket_categories', 'order_items.TicketCategoryID', '=', 'ticket_categories.ID')
            ->join('events', 'ticket_categories.EventID', '=', 'events.ID')
            ->select('orders.OrderNo', 'orders.TotalAmount', 'orders.PaymentStatus','orders.CreatedDate','events.EventName','events.Location','ticket_categories.CategoryName','order_items.Qty')
            ->orderBy('orders.CreatedDate', 'desc')->get();

        return Inertia::render('Customer/Dashboard', ['tickets' => $myTickets]); 
    })->name('customer.dashboard');

    // Modul Checkout & Transaksi
    Route::get('/checkout/{event_id}', [CheckoutController::class, 'index'])->name('checkout.index');
    Route::post('/checkout/{event_id}', [CheckoutController::class, 'store'])->name('checkout.store');

    // Manajemen Profil
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    // Setup 2FA
    Route::get('/2fa/setup', [TwoFactorController::class, 'setup'])->name('2fa.setup');
    Route::post('/2fa/verify', [TwoFactorController::class, 'verify'])->name('2fa.verify');
});

// Area Admin (Wajib 2FA)
Route::middleware(['auth', 'verified', '2fa_check'])->group(function () {
    
    // 1. Overview
    Route::get('/admin/dashboard', [AdminDashboardController::class, 'index'])->name('admin.dashboard');

    // 2. Events (CRUD Lengkap: Read, Create, Update, Delete)
    Route::get('/admin/events', [EventController::class, 'index'])->name('admin.events.index');
    Route::post('/admin/events', [EventController::class, 'store'])->name('admin.events.store');
    Route::put('/admin/events/{id}', [EventController::class, 'update'])->name('admin.events.update');
    Route::delete('/admin/events/{id}', [EventController::class, 'destroy'])->name('admin.events.destroy');

    // 3. Management Lainnya
    Route::get('/admin/tickets', [TicketController::class, 'index'])->name('admin.tickets.index');
    Route::get('/admin/transactions', [TransactionController::class, 'index'])->name('admin.transactions.index');
    Route::get('/admin/customers', [CustomerController::class, 'index'])->name('admin.customers.index');
});

// 2FA Challenge (Login)
Route::get('/2fa/challenge', [TwoFactorController::class, 'challenge'])->name('2fa.challenge')->middleware('auth');
Route::post('/2fa/challenge', [TwoFactorController::class, 'authenticate'])->middleware('auth');

require __DIR__.'/auth.php';